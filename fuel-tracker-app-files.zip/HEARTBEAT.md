# 每日邮件任务
- 每天早上 9:00，使用浏览器打开 https://outlook.live.com/mail/0/
- 检查收件箱，并将最新的"气象"相关邮件总结发送到我的 Telegram